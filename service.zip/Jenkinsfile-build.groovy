// Variables to change when forking a new project from stencil
projectName = 'springboot-service-stencil'
gitUrl = 'ssh://git@stash.int.corp.sun:2222/dpi/' + projectName + '.git'
gitBranch = 'master'

// Credentials are based on the pi-digital-jenkins user
piDigitalCreds = '9c7e9bfe-ff5b-413e-973c-874d5986d19b'
jennyHelpersCreds = 'cc857005-08d0-4e4d-b630-5722f2a7c08f'
nexusUploadCredentials = 'aebc7081-413a-4079-ba8f-1067add41283'

buildSlaveLabel = 'DPI-slave-java'

//fortifyProjectVersionId = '334'

def checkpoint = fileLoader.fromGit('checkpoint.groovy', 'ssh://git@stash:2222/jh/ghetto_checkpoint.git', 'master', jennyHelpersCreds, buildSlaveLabel)
//def fortifyUtil = fileLoader.fromGit('fortify.groovy', 'ssh://git@bitbucket:2222/dpi/jenkins-pipeline-utilities.git', 'master', piDigitalCreds, buildSlaveLabel)
def notification = fileLoader.fromGit("email-notifier.groovy", 'ssh://git@stash:2222/jh/email-notifier.git', 'master', jennyHelpersCreds, buildSlaveLabel)
notification.initialiseNotification(projectName, checkpoint)

properties([
    pipelineTriggers([
        [$class: "SCMTrigger", scmpoll_spec: ""],
    ]),
    parameters([
        string(defaultValue: '', description: '', name: 'CHECKPOINT')
    ])
])

notification.mail(buildSlaveLabel, 'Build & Publish to Nexus') {
    withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: nexusUploadCredentials, usernameVariable: 'NEXUS_USERNAME', passwordVariable: 'NEXUS_PASSWORD']]) {
        withEnv(['JAVA_HOME=/apps/tools/java/current-version-8']) {
            sh 'env'
            git credentialsId: piDigitalCreds, url: gitUrl, branch: gitBranch

            sh 'chmod +x ci.sh'
            sh './ci.sh'
        }
    }
}

notification.mail(buildSlaveLabel, 'Publish Reports') {
    publishHTML(target: [allowMissing: false, alwaysLinkToLastBuild: true, keepAll: true, reportDir: 'build/reports/tests/test', reportFiles: 'index.html', reportName: 'Unit Tests Results'])
    publishHTML(target: [allowMissing: false, alwaysLinkToLastBuild: true, keepAll: true, reportDir: 'build/asciidoc/html5', reportFiles: 'index.html', reportName: 'API Documentation'])
    publishHTML(target: [allowMissing: false, alwaysLinkToLastBuild: true, keepAll: true, reportDir: 'build/reports/checkstyle', reportFiles: 'main.html', reportName: 'Checkstyle Report'])
    publishHTML(target: [allowMissing: false, alwaysLinkToLastBuild: true, keepAll: true, reportDir: 'build/reports/jacoco/test/html', reportFiles: 'index.html', reportName: 'Coverage Report'])
}

notification.mail(buildSlaveLabel, 'Trigger Deployments') {
    build job: 'springboot-service-stencil-deploy', wait: false, parameters: [[$class: 'StringParameterValue', name: 'BUILD_NUMBER', value: env.BUILD_NUMBER]]
}

//notification.mail(fortifyUtil.nodeLabel, "Run Fortify") {
//    checkout scm
//    fortifyUtil.javaScanAndUpload(fortifyProjectVersionId)
//}
