// Variables to change when forking a new project from stencil
projectName = 'springboot-service-stencil'
gitUrl = 'ssh://git@stash.int.corp.sun:2222/dpi/' + projectName + '.git'
gitBranch = 'master'

// Credentials are based on the pi-digital-jenkins user
piDigitalCreds = '9c7e9bfe-ff5b-413e-973c-874d5986d19b'
jennyHelpersCreds = 'cc857005-08d0-4e4d-b630-5722f2a7c08f'
caCertUserCredentials = '34aabb09-03d1-43ca-b97c-4551a7f3c77e'
awsCredentials = 'aws-s-account'
deploySlaveLabel = 'DPI-slave-ansible'

dev_elb_name = projectName + '-dev'
dev_deploy_env = 'dev'
sys_elb_name = projectName + '-sys'
sys_deploy_env = 'sys'
uat_elb_name = projectName + '-uat'
uat_deploy_env = 'uat'

timeForTimeout = 120
unitForTimeout = 'SECONDS'

def checkpoint = fileLoader.fromGit('checkpoint.groovy', 'ssh://git@stash:2222/jh/ghetto_checkpoint.git', 'master', jennyHelpersCreds, deploySlaveLabel)

def notification = fileLoader.fromGit("email-notifier.groovy", 'ssh://git@stash:2222/jh/email-notifier.git', 'master', jennyHelpersCreds, deploySlaveLabel)
notification.initialiseNotification(projectName, checkpoint)

currentBuild.displayName = '#' + env.BUILD_NUMBER

properties([
    disableConcurrentBuilds(),
    parameters([
        string(defaultValue: '', description: '', name: 'BUILD_NUMBER'),
        string(defaultValue: '', description: '', name: 'CHECKPOINT')
    ])
])

notification.mail(deploySlaveLabel, 'Deploy to DEV') {
    // All of the deploy steps below use Ansible. This configuration will change when moving to Openshift
    deployNexusArtifactToAWSHost(env.BUILD_NUMBER, dev_deploy_env, dev_elb_name)
}

//    checkpoint.stage('Integration Test') {
//        node(integrationTestSlaveLabel) {
//            sh 'env'
//            checkout scm
//            executeTaskAndPublishTaskResults('integration-test.sh', 'integrationTest', 'Integration Tests Results')
//        }
//    }

notification.mail(deploySlaveLabel, 'Deploy to SYS') {
    timeout(time: timeForTimeout, unit: unitForTimeout) {
        input message: 'Deploy to SYS?', ok: 'Deploy'
    }
    deployNexusArtifactToAWSHost(env.BUILD_NUMBER, sys_deploy_env, sys_elb_name)
}

notification.mail(deploySlaveLabel, 'Deploy to UAT') {
    timeout(time: timeForTimeout, unit: unitForTimeout) {
        input message: 'Deploy to UAT?', ok: 'Deploy'
    }
    deployNexusArtifactToAWSHost(env.BUILD_NUMBER, uat_deploy_env, uat_elb_name)
}

notification.mail(deploySlaveLabel, 'Deploy to PROD') {
    timeout(time: timeForTimeout, unit: unitForTimeout) {
        input message: 'Deploy to PROD?', ok: 'Deploy', parameters: [
            string(name: 'U_NUMBER'),
            password(name: 'PASSWORD'),
            string(name: 'CHANGE_REQUEST_NUMBER')
        ]
    }
    // TODO: Uncomment following once the PROD infrastructure is setup
    //checkParametersAreNotEmpty()
    //createAndDeploy(env.BUILD_NUMBER, prod_deploy_env)
}

void cleanUp() {
    sh "rm -rf ${projectName}"
    sh 'rm -rf deployment-automation'
    sh 'rm -rf deployment-history'
}

void cloneDeploymentHistory() {
    wrap([$class: 'MaskPasswordsBuildWrapper']) {
        sh "git clone https://${U_NUMBER}:${PASSWORD}@stash.int.corp.sun/scm/dig/deployment-history.git"
    }
}

void createAndDeploy(build_number, env) {
    dir('deployment-automation') {
        git changelog: false, credentialsId: piDigitalCreds, poll: false, url: 'ssh://git@stash:2222/dig/deployment-automation.git'
    }
    cloneDeploymentHistory()
    dir(projectName) {
        git credentialsId: piDigitalCreds, url: gitUrl, branch: gitBranch

        dir('deployment') {
            withCredentials([[$class          : 'UsernamePasswordMultiBinding',
                              credentialsId   : awsCredentials,
                              usernameVariable: 'AWS_API_USER',
                              passwordVariable: 'AWS_API_PASSWORD']]) {
                withEnv([
                    "AWS_API_USER=$env.AWS_API_USER",
                    "AWS_API_PASSWORD=$env.AWS_API_PASSWORD",
                    "PROJECT_NAME=$projectName",
                    "BUILD_PIPELINE_NUMBER=${build_number}",
                    "U_NUMBER=${U_NUMBER}",
                    "CHANGE_REQUEST_NUMBER=${CHANGE_REQUEST_NUMBER}"]) {
                    sh 'env'
                    wrap([$class: 'MaskPasswordsBuildWrapper']) {
                        sh "./create-instance.sh ${build_number} ${env} ${projectName} -vvvv"
                    }
                }
            }
        }
    }
    cleanUp()
}

void deployNexusArtifactToAWSHost(String build_number, String deploy_env, String deploy_elb_name) {
    sh 'env'

    dir('deployment-automation') {
        // Point to DPI for stable immutable deployment
        git changelog: false, credentialsId: piDigitalCreds, poll: false, url: 'ssh://git@stash:2222/dpi/deployment-automation.git'
    }

    dir(projectName) {
        checkout scm
        dir('deployment') {
            withCredentials([[$class          : 'UsernamePasswordMultiBinding',
                              credentialsId   : awsCredentials,
                              usernameVariable: 'AWS_API_USER',
                              passwordVariable: 'AWS_API_PASSWORD'
                             ],
                             [$class          : 'UsernamePasswordMultiBinding',
                              credentialsId   : caCertUserCredentials,
                              usernameVariable: 'CA_CERT_USER',
                              passwordVariable: 'CA_CERT_PASS'
                             ]]) {
                sh "./immutable-deploy.sh ${build_number} ${deploy_env} ${deploy_elb_name} ${projectName} -vvvv"
            }
        }
    }
}

void checkParametersAreNotEmpty() {
    def parameters = [
        [var: 'U_NUMBER', value: U_NUMBER.toString()],
        [var: 'PASSWORD', value: PASSWORD.toString()],
        [var: 'CHANGE_REQUEST_NUMBER', value: CHANGE_REQUEST_NUMBER.toString()],
    ]
    def emptyParameters = []
    for (it in parameters) {
        if (it.value.equals('')) {
            emptyParameters.add(it.var)
        }
    }
    if (emptyParameters.size() > 0) {
        error("Missing parameters: " + emptyParameters.toString())
    }
}
