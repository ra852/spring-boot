# Spring Boot Service Stencil 

[![Build Status](https://alfred.int.corp.sun/job/DPI-Projects/job/stencils/job/springboot-service-stencil/job/feature%252Fspringboot-1.5.x/badge/icon)](https://alfred.int.corp.sun/job/DPI-Projects/job/stencils/job/springboot-service-stencil/job/master/)

This project could be used as a starting point for micro service/API development based on Spring Boot 1.5.x technology.
Do a fork and get going!!

Note: 
This repo is used for spiking with Spring Boot 1.5.x. Some libraries are not final versions yet and may contain bugs.
They are fully tested in real projects and whether backward compatible with existing API foundations. 
However, feel free to use it and contribute back for any issues.


## Custodians

[BT Digital Services Nimble](<TDL-Digital-Services-Nimble@suncorp.com.au>)


## Things to change when you use this

* `gradle/java.gradle`: JDK version (default: Java 1.8)
* `settings.gradle`: project name
* `gradle.properties`: project info section, library versions
* `src/main/resources/application.yml`: context path, swagger config, hystrix timeout config
* `src/main/java` and `src/test/java`: package name
* `LoggingAspect.java`: logging package pointcut
* `logback-base.xml` and every `logback-<env>.xml`: package name
* `application.yml` and every `application-<env>.yml`: update the configuration marked with `TODO`
* `HelloResource.java`: rename the class and implement with actual solution
* `DependentServiceProperties.java`: replace with actual implementation
* `DependentServiceHealthIndicator.java` and `DependentService.java`: replace with actual implementation
* `DependentServiceConfiguration.java` and `HealthCheckConfiguration.java`: replace with actual implementation
* `src/test/resources/pacts`: rename and modify the sample pact file with actual pact
* `gradle/pact-test.gradle`: pact configuration
* `SwaggerToMarkupTest.java`: static API doc generation
* `deployment/env` folder: AWS deployment scripts (notification email, SSL certificate domain names)
* `deployment/dev|sys|uat.yml`: appspace - create your own in your Workspace and define at top of files and ensure included in `ec2_application_tags`. 
* `deployment/configure-common.yml`: change `nexus_url_prefix` to match the new package name, `appinfo_url` to match the new context-path defined in `application.yml`
* Create a Jenkins pipeline for your service - See below
* `Jenkinsfile`: configure your Jenkins pipeline and change required variables at the top
* `rc.verify`: update endpoint
* Add your pipeline Jenkins job config to [BuildReactor Settings](https://stash.int.corp.sun/projects/DPI/repos/buildreactor-settings/browse) and re-import on physical Lync-TV/monitors. See `alfred_templates.json` file for example.
* This `README.md`


### Local build

`$ ./gradlew`  - will run the default build

`$ ./build.sh` or `$ ./build.bat` - will run the default build and also execute pactVerify

If running on the Windows command prompt use the corresponding .bat files.

For building locally you may need to have a local proxy set up. Cntlm works for this. See http://confluence.int.corp.sun/confluence/pages/viewpage.action?pageId=126979321


### CI build

To run the build in a CI environment run the following:

`$ ./ci.sh`

See section below for more about Jenkins vs Alfred.


### How to run it locally

`$ ./gradlew bootRun`

Check if everything is fine by invoking from browser: `http://localhost:8080/my-service/api/hello?name=James`

Include the following in the HTTP request headers:<br/>
- Accept: application/vnd.api+json<br/>
- X-Correlation-Id: CORR1234567<br/>
- X-Client-Id: CLIENTID<br/>
- X-Client-Version: 1.0.0<br/>

Note: server port is configured using the `server.port` property in the `config/application-local.yml` file


### How to publish to maven repository

`$ ./gradlew publish`


### How to release

`$ ./gradlew release`


## Useful Spring Boot endpoints

* Build info: `/info`
* Healthcheck: `/health`
* Environment: `/env`
* Metrics: `/metrics`


## API documentation endpoints

* Static HTML: `/index.html`
* Swagger UI: `/swagger-ui.html`
* Swagger JSON Schema: `/v2/api-docs`


## Standards and Guidelines in API Development

* [Naming Standards & Guidelines for Applications and APIs](http://confluence.int.corp.sun/confluence/pages/viewpage.action?pageId=184305701)
* [Standards & Guidelines for API Development](http://confluence.int.corp.sun/confluence/pages/viewpage.action?pageId=196340073)


## Jenkins pipeline

This stencil now provides the functionality to configure your Jenkins pipeline as code. Note that this is only available on the [Alfred instance](https://alfred.int.corp.sun/).

The default stages included are:
* build and test
* publish artifact Nexus `http://nexus/`

When you fork the stencil project, ensure you change the properties in `Jenkinsfile` to reflect the correct Jenkins slave to run on

To create your new pipeline: 

* On `http://alfred.int.corp.sun/` clone the template pipeline *[DPI-springboot-stencil](https://alfred.int.corp.sun/job/DPI-Projects/job/stencils/job/springboot-service-stencil/)*.
* Ensure that name of the new pipeline starts with *DPI-*
* In the job configuration, go to *Pipeline* -> *SCM* -> *Repositories*
** Change the *Repository URL* with your newly forked Git SSH URL

To setup the Stash Webhook to automatically notify Jenkins of a commit, follow the documentation at '[How do I avoid polling for changes from Stash?](http://confluence.int.corp.sun/confluence/pages/viewpage.action?pageId=175001293)'. Make sure your *Repo Clone URL* directly matches the *Repository URL* from the last step.


## Old Jenkins vs New Jenkins (Alfred)

If you are planning to run your build pipeline on (the old) Jenkins, http://jenkins/, then be aware that you may have to enable Gradle to use a proxy to retrieve dependencies. Not needed if using (new Jenkins) Alfred, http://alfred/.

In the `ci.sh` file set the appropriate proxy settings before executing any Gradle commands:

`export GRADLE_PROPS="-Dhttp.proxyHost=127.0.0.1 -Dhttp.proxyPort=3128 -Dhttps.proxyHost=127.0.0.1 -Dhttps.proxyPort=3128"`


## Get CI and Dev deploy up and running on New Jenkins (Alfred)
* Change rootProject.name in settings.gradle
* Change projectName in Jenkinsfile.groovy to match rootProject.name
* Add Ansible to your path in configure-instance.sh and/or create-instance.sh, if you get an error. 
* Add any other environmental variables you need for credentials and other tools, in
configure-instance.sh and/or create-instance.sh.
e.g: `export MIDDLEWARE_SVN_PASSWORD=XXXXXX`
* Set up ec2 instance as dev host, by uncommenting and running `create-instance.sh` in GROOVY file.
* Define hostname variable for dev deploy job with the IP of new AWS host.
* Comment out create-instance.sh and uncomment configure-instance.sh section in dev deploy job
* Setup/configure the pipeline as mentioned in above section

You should now be able to run ci and dev-deploy job on the pipeline!
Verify by making call to:  `http://{HOST_IP}:10080/my-service/info`

## Setup Dynatrace
Please refer to this page http://confluence.int.corp.sun/confluence/display/SM/Dynatrace+%7C+User+Documentation

## Other things

Script file permissions
* If committing a new executable script, from Windows the +x permission will not be preserved. Make sure you run `git update-index --chmod=+x filename` before you commit. This way you won't need to chmod in your Jenkins slave.
* Change version prefix in configure-common.yml and gradle.properties, identically to something other than 0.1, if you want versioning to something other than the format 0.1b-BUILD_NUMBER

## Troubleshooting

* I started doing some development off the stencil and I suddenly started getting compile error related to LoggingAspects when I do gradlew bootRun:
    ** There are some errors that are known to occur due to having nested lists in the environmental .yml files.
      When these environmental values are picked up by Properties classes in au.com.suncorp.insurance.{service_name}.config package,
      errors are thrown for reasons unclear. If the likely cause is within these new Properties class handling, to resolve this error replace the line in the LoggingAspect class:
        `@Pointcut("within(au.com.suncorp.insurance.myservice..*)")` with:
        `@Pointcut("within(au.com.suncorp.insurance.myservice..*) && !within(au.com.suncorp.insurance.myservice.config..*)")`
       This disables the logging of data flow of beans instantiated within the config package.
      
