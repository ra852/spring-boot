#!/usr/bin/env bash
export GRADLE_PROPS=
export SPRING_PROFILES_ACTIVE=test

./gradlew $GRADLE_PROPS stopService
./gradlew $GRADLE_PROPS clean build pactVerify $@