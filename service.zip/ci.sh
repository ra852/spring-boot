#!/usr/bin/env bash
set -e
export SPRING_PROFILES_ACTIVE=test
export GRADLE_USER_HOME=/apps/.gradle
#export GRADLE_PROPS="-Dhttp.proxyHost=127.0.0.1 -Dhttp.proxyPort=3128 -Dhttps.proxyHost=127.0.0.1 -Dhttps.proxyPort=3128"

#Do not run in daemon mode for CI
./gradlew $GRADLE_PROPS --stop
./gradlew $GRADLE_PROPS --no-daemon stopService
./gradlew $GRADLE_PROPS --no-daemon clean build pactVerify publish $@
./gradlew $GRADLE_PROPS --stop