These deployment configuration scripts are samples for others to follow.

