CURRENT_DIRECTORY=`pwd`
SHARED_PLAYBOOKS=$CURRENT_DIRECTORY/../../deployment-automation
export ANSIBLE_CONFIG=$SHARED_PLAYBOOKS/ansible.cfg

ansible-playbook continuous-integration.yml --extra-vars="build_pipeline_number=213 env_config_file='$CURRENT_DIRECTORY/env/uat.xint.yml' shared_playbooks='$SHARED_PLAYBOOKS'"  -i "$SHARED_PLAYBOOKS/hosts" "${@:3}"

