CURRENT_DIRECTORY=`pwd`
SHARED_PLAYBOOKS=$CURRENT_DIRECTORY/../../deployment-automation
export ANSIBLE_CONFIG=$SHARED_PLAYBOOKS/ansible.cfg

source /apps/ansible-1.7.2/hacking/env-setup

ansible-playbook create-instance.yml --extra-vars="build_pipeline_number=$1 env_config_file='$CURRENT_DIRECTORY/env/$2.yml' project_name=$3 shared_playbooks='$SHARED_PLAYBOOKS'"  -i "$SHARED_PLAYBOOKS/hosts" "${@:4}"

