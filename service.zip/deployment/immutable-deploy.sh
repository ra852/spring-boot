#!/bin/bash
# immutable deploy
#
if [ $# -lt 3 ]; then
    echo "$1 = build number to deploy, e.g. 114"
    echo "$2 = environment name to deploy, which yml file to call in deployment/env folder e.g. dev"
    echo "$3 = elb name"
    echo "$4 = projectName"
    exit 1
fi
source /apps/ansible-1.7.2/hacking/env-setup
ansible --version
export PYTHONUNBUFFERED=1
export MIDDLEWARE_SVN_PASSWORD=Ansible1
export CURRENT_DIRECTORY=`pwd`
export BUILD_NUMBER=$1
export ENVIRONMENT=$2
export ELB_NAME=$3
SHARED_PLAYBOOKS=$CURRENT_DIRECTORY/../../deployment-automation
ANSIBLE_CONFIG=$SHARED_PLAYBOOKS/ansible.cfg

ansible-playbook "$SHARED_PLAYBOOKS/immutable-ec2-deployment.yml" --extra-vars="build_pipeline_number=$1 env_config_file='$CURRENT_DIRECTORY/env/$2.yml' config_instance_playbook='$CURRENT_DIRECTORY/configure-common.yml' shared_playbooks='$SHARED_PLAYBOOKS' elb_name=$3 project_name=$4" -i "$SHARED_PLAYBOOKS/hosts" "${@:5}"
