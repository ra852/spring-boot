////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2016, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package au.com.suncorp.insurance.myservice.config;

import au.com.suncorp.insurance.myservice.config.properties.DependentServiceProperties;
import au.com.suncorp.insurance.myservice.provider.DependentService;
import au.com.suncorp.insurance.myservice.provider.mapper.HelloMapper;
import au.com.suncorp.insurance.myservice.stub.DependentServiceRestOperationsStub;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.web.client.RestTemplate;

@Configuration
@EnableConfigurationProperties(DependentServiceProperties.class)
@RefreshScope
public class DependentServiceConfiguration {
    @Autowired
    private DependentServiceProperties dependentServiceProperties;

    @Autowired
    private RestTemplate restTemplate;

    @Autowired
    private HelloMapper helloMapper;

    @Bean
    @Profile("!dependentServiceStub")
    public DependentService helloService() {
        //TODO: Replace stub with actual restTemplate
        //return new DependentCustomerService(restTemplate, dependentServiceProperties, helloMapper);
        return new DependentService(new DependentServiceRestOperationsStub(), dependentServiceProperties, helloMapper);
    }

    @Bean
    @Profile("dependentServiceStub")
    public DependentService helloServiceStub() {
        return new DependentService(new DependentServiceRestOperationsStub(), dependentServiceProperties, helloMapper);
    }
}
