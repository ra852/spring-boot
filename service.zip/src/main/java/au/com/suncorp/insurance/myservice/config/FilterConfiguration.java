////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2016, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////

package au.com.suncorp.insurance.myservice.config;

import javax.servlet.Filter;

import au.com.suncorp.insurance.gi.api.common.config.properties.CorsProperties;
import au.com.suncorp.insurance.gi.api.common.filter.CacheControlHeadersFilter;
import au.com.suncorp.insurance.gi.api.common.filter.HystrixRequestContextFilter;
import au.com.suncorp.insurance.gi.api.common.filter.LoggingFilter;
import au.com.suncorp.insurance.gi.api.common.filter.SimpleCorsFilter;
import au.com.suncorp.insurance.gi.api.common.filter.StatelessCsrfFilter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
@EnableConfigurationProperties(CorsProperties.class)
public class FilterConfiguration {
    @Autowired
    private CorsProperties corsProperties;

    @Bean
    public FilterRegistrationBean loggingFilterRegistrationBean() {
        return getFilterRegistrationBean(new LoggingFilter(), FilterRegistrationBean.HIGHEST_PRECEDENCE);
    }

    @Bean
    public FilterRegistrationBean simpleCorsFilterRegistrationBean() {
        return getFilterRegistrationBean(new SimpleCorsFilter(corsProperties), FilterRegistrationBean.HIGHEST_PRECEDENCE + 1);
    }

    @Bean
    public FilterRegistrationBean statelessCsrfFilterRegistrationBean() {
        return getFilterRegistrationBean(new StatelessCsrfFilter(), FilterRegistrationBean.HIGHEST_PRECEDENCE + 2);
    }

    @Bean
    public FilterRegistrationBean cacheControlHeadersFilterRegistrationBean() {
        return getFilterRegistrationBean(new CacheControlHeadersFilter(), FilterRegistrationBean.HIGHEST_PRECEDENCE + 3);
    }

    @Bean
    @ConditionalOnProperty({"spring.cloud.circuit.breaker.enabled"})
    public FilterRegistrationBean hystrixRequestContextFilterFilterRegistrationBean() {
        return getFilterRegistrationBean(new HystrixRequestContextFilter(), FilterRegistrationBean.HIGHEST_PRECEDENCE + 4);
    }

    private FilterRegistrationBean getFilterRegistrationBean(Filter filter, int order) {
        FilterRegistrationBean filterRegistrationBean = new FilterRegistrationBean();

        filterRegistrationBean.setFilter(filter);
        filterRegistrationBean.setOrder(order);

        return filterRegistrationBean;
    }
}
