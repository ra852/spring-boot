////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2016, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package au.com.suncorp.insurance.myservice.config;

import static au.com.suncorp.insurance.myservice.constant.Constants.HYSTRIX_GROUP_KEY_DEPENDENT_SERVICE;

import au.com.suncorp.insurance.myservice.config.properties.DependentServiceProperties;
import au.com.suncorp.insurance.myservice.provider.DependentServiceHealthIndicator;
import au.com.suncorp.insurance.gi.api.common.healthcheck.HealthCheckException;
import au.com.suncorp.insurance.gi.api.common.healthcheck.checker.SpringBootHealthChecker;
import au.com.suncorp.insurance.gi.api.common.healthcheck.provider.SingleEnvironmentServiceProviderConfiguration;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.HealthIndicator;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.retry.annotation.Retryable;
import org.springframework.web.client.RestTemplate;

@Configuration
@EnableConfigurationProperties(DependentServiceProperties.class)
public class HealthCheckConfiguration {
    private static final String DEPENDENT_SERVICE_HEALTH_CHECK_NAME = "dependentServiceHealthCheck";

    @Autowired
    private DependentServiceProperties dependentServiceProperties;

    @Autowired
    private RestTemplate restTemplate;

    @Bean(name = DEPENDENT_SERVICE_HEALTH_CHECK_NAME)
    @RefreshScope
    public HealthIndicator dependentServiceHealthCheck() {
        // Note: Available health checkers in api-common are
        // - SpringBootHealthChecker: checks against spring boot '/health' endpoint
        // - HttpResponseHealthChecker: checks against HTTP OK status response (and optionally response text)

        return new DependentServiceHealthIndicator(providerConfiguration(dependentServiceProperties),
                DEPENDENT_SERVICE_HEALTH_CHECK_NAME, dependentServiceSpringBootHealthChecker());
    }

    @Bean
    public SpringBootHealthChecker dependentServiceSpringBootHealthChecker() {
        return new SpringBootHealthChecker(restTemplate) {
            @HystrixCommand(groupKey = HYSTRIX_GROUP_KEY_DEPENDENT_SERVICE, commandKey = HYSTRIX_GROUP_KEY_DEPENDENT_SERVICE + "CheckHealth")
            @Retryable
            @Override
            public Health check(String healthUrl) throws HealthCheckException {
                return super.check(healthUrl);
            }
        };
    }

    private SingleEnvironmentServiceProviderConfiguration providerConfiguration(DependentServiceProperties dependentServiceProperties) {
        String endpoint = dependentServiceProperties.getAddress().getBase() + dependentServiceProperties.getAddress().getHealth();
        DependentServiceProperties.Downtime downtime = dependentServiceProperties.getDowntime();

        return new SingleEnvironmentServiceProviderConfiguration(downtime.isEnabled(), downtime.getPeriod(), endpoint);
    }
}
