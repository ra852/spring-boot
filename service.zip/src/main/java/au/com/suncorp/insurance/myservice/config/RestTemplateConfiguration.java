////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2016, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package au.com.suncorp.insurance.myservice.config;

import static au.com.suncorp.insurance.gi.api.common.constant.CommonConstants.CLIENT_ID_FIELD_NAME;
import static au.com.suncorp.insurance.gi.api.common.constant.CommonConstants.CLIENT_VERSION_FIELD_NAME;
import static au.com.suncorp.insurance.gi.api.common.constant.CommonConstants.CORRELATION_ID_FIELD_NAME;

import java.io.IOException;
import java.util.Arrays;

import au.com.suncorp.insurance.gi.api.common.config.properties.ApplicationProperties;
import au.com.suncorp.insurance.gi.api.common.context.RequestContextHolder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpRequest;
import org.springframework.http.client.ClientHttpRequestExecution;
import org.springframework.http.client.ClientHttpRequestFactory;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;

@Configuration
@EnableConfigurationProperties(ApplicationProperties.class)
public class RestTemplateConfiguration {
    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private ApplicationProperties applicationProperties;

    @Bean
    public RestTemplate restTemplate() {
        RestTemplate restTemplate = new RestTemplate(httpRequestFactory());
        restTemplate.setInterceptors(Arrays.asList(new RequestHeaderInterceptor()));

        return restTemplate;
    }

    @Bean
    public ClientHttpRequestFactory httpRequestFactory() {
        return new HttpComponentsClientHttpRequestFactory();
    }

    private class RequestHeaderInterceptor implements ClientHttpRequestInterceptor {
        @Override
        public ClientHttpResponse intercept(HttpRequest request, byte[] body, ClientHttpRequestExecution execution) throws IOException {
            HttpHeaders headers = request.getHeaders();
            headers.set(CORRELATION_ID_FIELD_NAME, RequestContextHolder.get().getCorrelationId());
            headers.set(CLIENT_ID_FIELD_NAME, applicationProperties.getId());
            headers.set(CLIENT_VERSION_FIELD_NAME, applicationProperties.getVersion());

            return execution.execute(request, body);
        }
    }
}
