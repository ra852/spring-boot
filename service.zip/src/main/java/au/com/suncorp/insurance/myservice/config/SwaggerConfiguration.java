////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2016, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////

package au.com.suncorp.insurance.myservice.config;

import static au.com.suncorp.insurance.gi.api.common.constant.CommonConstants.CLIENT_ID_FIELD_NAME;
import static au.com.suncorp.insurance.gi.api.common.constant.CommonConstants.CLIENT_VERSION_FIELD_NAME;
import static au.com.suncorp.insurance.gi.api.common.constant.CommonConstants.CORRELATION_ID_FIELD_NAME;
import static com.google.common.collect.Lists.newArrayList;
import static springfox.documentation.builders.PathSelectors.regex;
import static springfox.documentation.schema.AlternateTypeRules.newRule;

import java.util.ArrayList;
import java.util.List;

import au.com.suncorp.insurance.myservice.config.properties.SwaggerProperties;
import au.com.suncorp.insurance.gi.api.common.constant.CommonConstants;
import com.fasterxml.classmate.TypeResolver;
import com.google.common.base.Predicate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.ResponseEntity;
import org.springframework.web.context.request.async.DeferredResult;
import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.ParameterBuilder;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.schema.ModelRef;
import springfox.documentation.schema.WildcardType;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.ApiKey;
import springfox.documentation.service.AuthorizationScope;
import springfox.documentation.service.Contact;
import springfox.documentation.service.Parameter;
import springfox.documentation.service.SecurityReference;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spi.service.contexts.SecurityContext;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger.web.ApiKeyVehicle;
import springfox.documentation.swagger.web.SecurityConfiguration;
import springfox.documentation.swagger.web.UiConfiguration;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

@Configuration
@EnableConfigurationProperties(SwaggerProperties.class)
@EnableSwagger2
public class SwaggerConfiguration {
    private static final String DEFAULT_INCLUDE_PATTERN = CommonConstants.REST_BASE_URL_PATTERN + "/.*";

    @Autowired
    private SwaggerProperties swaggerProperties;

    @Autowired
    private TypeResolver typeResolver;

    @Bean
    public Docket Api() {
        return new Docket(DocumentationType.SWAGGER_2)
                .apiInfo(apiInfo())
                .select()
                .apis(RequestHandlerSelectors.any())
                .paths(apiPaths())
                .build()
                .pathMapping("/")
                .genericModelSubstitutes(ResponseEntity.class)
                .alternateTypeRules(
                        newRule(typeResolver.resolve(DeferredResult.class, typeResolver.resolve(ResponseEntity.class, WildcardType.class)),
                                typeResolver.resolve(WildcardType.class)))
                .globalOperationParameters(globalOperationParameters())
                .useDefaultResponseMessages(true) //Flag to indicate if default http response codes need to be used or not
                .securitySchemes(newArrayList(apiKey()))
                .securityContexts(newArrayList(securityContext()))
                .enableUrlTemplating(false); //If true, use 'form style query' for generated paths
    }

    /**
     * Optional swagger-ui security configuration for oauth and apiKey settings.
     */
    @Bean
    public SecurityConfiguration security() {
        return new SecurityConfiguration(
                "test-app-client-id",
                "test-app-client-secret",
                "test-app-realm",
                "test-app",
                "apiKey",
                ApiKeyVehicle.HEADER,
                "api_key",
                ",");
    }

    /**
     * Optional swagger-ui ui configuration currently only supports the validation url.
     */
    @Bean
    public UiConfiguration uiConfig() {
        return new UiConfiguration(null);
    }

    /**
     * API Info as it appears on the swagger-ui page
     */
    private ApiInfo apiInfo() {
        return new ApiInfoBuilder()
                .title(swaggerProperties.getTitle())
                .description(swaggerProperties.getDescription())
                .termsOfServiceUrl(swaggerProperties.getTermsOfServiceUrl())
                .contact(new Contact(
                        swaggerProperties.getContact().getName(),
                        swaggerProperties.getContact().getUrl(),
                        swaggerProperties.getContact().getEmail()))
                .license(swaggerProperties.getLicense())
                .licenseUrl(swaggerProperties.getLicenseUrl())
                .version(swaggerProperties.getVersion())
                .build();
    }

    /**
     * Allows selection of Path's using a predicate. The example here uses an `any predicate (default).
     */
    private Predicate<String> apiPaths() {
        return regex(DEFAULT_INCLUDE_PATTERN);
    }

    /**
     * Global operation parameters.
     */
    private List<Parameter> globalOperationParameters() {
        List<Parameter> parameterList = new ArrayList<>();

        parameterList.add(createClientInfoHeaderParameter(CORRELATION_ID_FIELD_NAME, "Correlation ID (36 chars max: alphanumeric and hyphen)"));
        parameterList.add(createClientInfoHeaderParameter(CLIENT_ID_FIELD_NAME, "Client ID (50 chars max: alphanumeric and hyphen)"));
        parameterList.add(createClientInfoHeaderParameter(CLIENT_VERSION_FIELD_NAME, "Client Version (10 chars max: alphanumeric, dot & hyphen)"));

        return parameterList;
    }

    private Parameter createClientInfoHeaderParameter(String name, String description) {
        Parameter parameter = new ParameterBuilder()
                .name(name)
                .description(description)
                .parameterType("header")
                .modelRef(new ModelRef("string"))
                .required(true)
                .build();

        return parameter;
    }

    /**
     * Sets up the security schemes used to protect the apis. Supported schemes are ApiKey, BasicAuth and OAuth.
     * Here we use ApiKey as the security schema that is identified by the name mykey.
     */
    private ApiKey apiKey() {
        return new ApiKey("mykey", "api_key", "header");
    }

    /**
     * Provides a way to globally set up security contexts for operation.
     * The idea here is that we provide a way to select operations to be protected by one of the specified security schemes.
     */
    private SecurityContext securityContext() {
        return SecurityContext.builder()
                .securityReferences(defaultAuth())
                .forPaths(regex("/anyPath.*")) //Selector for the paths this security context applies to.
                .build();
    }

    private List<SecurityReference> defaultAuth() {
        AuthorizationScope authorizationScope
                = new AuthorizationScope("global", "accessEverything");
        AuthorizationScope[] authorizationScopes = new AuthorizationScope[1];
        authorizationScopes[0] = authorizationScope;
        return newArrayList(
                new SecurityReference("mykey", authorizationScopes));
    }
}
