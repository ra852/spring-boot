////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2017, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////

package au.com.suncorp.insurance.myservice.config;

import java.util.Optional;

import org.apache.catalina.connector.Connector;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.embedded.tomcat.TomcatEmbeddedServletContainerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;

@Configuration
public class TomcatConfiguration {
    private static final String SERVER_PORT = "server.port";
    private static final String SERVER_SSL_KEY_STORE = "server.ssl.key-store";
    private static final String ORG_APACHE_COYOTE_HTTP11_HTTP11_NIO_PROTOCOL = "org.apache.coyote.http11.Http11NioProtocol";
    @Autowired
    private Environment env;

    @Bean
    public TomcatEmbeddedServletContainerFactory tomcat() {
        TomcatEmbeddedServletContainerFactory tomcat = new TomcatEmbeddedServletContainerFactory();
        if (runningWithHttps()) {
            alsoRunWithHttp(tomcat);
        }
        return tomcat;
    }

    private void alsoRunWithHttp(TomcatEmbeddedServletContainerFactory tomcat) {
        Connector connector = new Connector(ORG_APACHE_COYOTE_HTTP11_HTTP11_NIO_PROTOCOL);
        connector.setPort(portForHttp());
        tomcat.addAdditionalTomcatConnectors(connector);
    }

    private int portForHttp() {
        return httpsPort() - 1;
    }

    private boolean runningWithHttps() {
        return Optional.ofNullable(env.getProperty(SERVER_SSL_KEY_STORE)).isPresent();
    }

    private int httpsPort() {
        return Integer.parseInt(env.getProperty(SERVER_PORT));
    }

}
