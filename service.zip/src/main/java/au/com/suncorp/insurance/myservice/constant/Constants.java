////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2016, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////

package au.com.suncorp.insurance.myservice.constant;

/**
 * Application constants.
 */
public final class Constants {
    public static final String SPRING_PROFILE_TEST = "test";
    public static final String SPRING_PROFILE_LOCAL = "local";
    public static final String SPRING_PROFILE_DEVELOPMENT = "dev";
    public static final String SPRING_PROFILE_PRODUCTION = "prod";

    public static final String HYSTRIX_GROUP_KEY_DEPENDENT_SERVICE = "DependentService";

    private Constants() {
    }
}
