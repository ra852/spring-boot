////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2016, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package au.com.suncorp.insurance.myservice.provider;

import static au.com.suncorp.insurance.myservice.constant.Constants.HYSTRIX_GROUP_KEY_DEPENDENT_SERVICE;

import java.net.URI;

import au.com.suncorp.insurance.myservice.config.properties.DependentServiceProperties;
import au.com.suncorp.insurance.myservice.model.Hello;
import au.com.suncorp.insurance.myservice.provider.domain.CustomerResponseVO;
import au.com.suncorp.insurance.myservice.provider.mapper.HelloMapper;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestOperations;
import org.springframework.web.util.UriTemplate;

public class DependentService {
    private final Logger logger = LoggerFactory.getLogger(this.getClass());
    private final RestOperations restOperations;
    private final DependentServiceProperties dependentServiceProperties;
    private final HelloMapper helloMapper;

    public DependentService(RestOperations restOperations, DependentServiceProperties dependentServiceProperties, HelloMapper helloMapper) {
        this.restOperations = restOperations;
        this.dependentServiceProperties = dependentServiceProperties;
        this.helloMapper = helloMapper;
    }

    @HystrixCommand(groupKey = HYSTRIX_GROUP_KEY_DEPENDENT_SERVICE, commandKey = HYSTRIX_GROUP_KEY_DEPENDENT_SERVICE + "GetCustomer")
    public Hello hello(String name, String title) {
        CustomerResponseVO customerResponseVO = callService(name);
        Hello hello = helloMapper.map(customerResponseVO, Hello.class);

        String greetingName = title != null ? (title + " " + name) : name;
        hello.setMessage("Hi " + greetingName + ", Hello There Too!");

        return hello;
    }

    private CustomerResponseVO callService(String name) {
        CustomerResponseVO customerResponseVO;
        String endpoint = dependentServiceProperties.getAddress().getBase() + dependentServiceProperties.getAddress().getService();
        URI uri = new UriTemplate(endpoint).expand(name);

        logger.info("Request: " + uri);

        try {
            HttpEntity<?> httpEntity = new HttpEntity<>(new HttpHeaders());
            ResponseEntity<CustomerResponseVO> responseEntity = restOperations.exchange(endpoint, HttpMethod.GET, httpEntity,
                    CustomerResponseVO.class, name);

            customerResponseVO = responseEntity.getBody();
            logger.info("Response: " + customerResponseVO);

        } catch (RestClientException rce) {
            throw new RuntimeException("Failed to get customer details from Dependent Service: " + uri, rce);
        }

        return customerResponseVO;
    }
}
