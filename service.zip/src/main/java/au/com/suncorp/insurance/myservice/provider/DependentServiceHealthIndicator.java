////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2016, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package au.com.suncorp.insurance.myservice.provider;

import au.com.suncorp.insurance.gi.api.common.healthcheck.HealthCheckException;
import au.com.suncorp.insurance.gi.api.common.healthcheck.SingleEnvironmentProviderHealthIndicator;
import au.com.suncorp.insurance.gi.api.common.healthcheck.checker.SpringBootHealthChecker;
import au.com.suncorp.insurance.gi.api.common.healthcheck.provider.SingleEnvironmentServiceProviderConfiguration;
import org.springframework.boot.actuate.health.Health;

public class DependentServiceHealthIndicator extends SingleEnvironmentProviderHealthIndicator {
    private final SpringBootHealthChecker springBootHealthChecker;
    private final SingleEnvironmentServiceProviderConfiguration providerConfiguration;

    public DependentServiceHealthIndicator(SingleEnvironmentServiceProviderConfiguration providerConfiguration, String name,
                                           SpringBootHealthChecker springBootHealthChecker) {
        super(providerConfiguration, name);
        this.providerConfiguration = providerConfiguration;
        this.springBootHealthChecker = springBootHealthChecker;
    }

    @Override
    protected Health doCheck() throws HealthCheckException {
        return springBootHealthChecker.check(providerConfiguration.getHealthEndpoint());
    }
}
