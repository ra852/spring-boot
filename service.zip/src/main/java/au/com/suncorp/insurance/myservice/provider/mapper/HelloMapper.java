////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2016, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package au.com.suncorp.insurance.myservice.provider.mapper;

import au.com.suncorp.insurance.myservice.model.Hello;
import au.com.suncorp.insurance.myservice.provider.domain.CustomerResponseVO;
import ma.glasnost.orika.MapperFactory;
import ma.glasnost.orika.converter.ConverterFactory;
import ma.glasnost.orika.converter.builtin.PassThroughConverter;
import ma.glasnost.orika.impl.ConfigurableMapper;
import org.joda.time.DateTime;
import org.springframework.stereotype.Component;

@Component
public class HelloMapper extends ConfigurableMapper {

    @Override
    protected void configure(MapperFactory factory) {
        registerConverters(factory.getConverterFactory());

        factory.classMap(CustomerResponseVO.class, Hello.class)
                .fieldAToB("id", "customerId")
                .fieldAToB("firstName", "customerName")
                .register();
    }

    private void registerConverters(ConverterFactory converterFactory) {
        converterFactory.registerConverter(new PassThroughConverter(DateTime.class));
    }
}
