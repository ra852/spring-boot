////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2016, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////

package au.com.suncorp.insurance.myservice.rest.dto.request;

import java.io.Serializable;

import com.google.common.base.MoreObjects;
import io.swagger.annotations.ApiModelProperty;
import org.hibernate.validator.constraints.NotEmpty;

public class HelloRequestDTO implements Serializable {
    @ApiModelProperty(required = true)
    @NotEmpty
    private String name;

    @ApiModelProperty(required = false)
    private String title;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    @Override
    public String toString() {
        return MoreObjects.toStringHelper(this)
                .add("name", name)
                .add("title", title)
                .toString();
    }
}
