////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2016, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////

package au.com.suncorp.insurance.myservice.rest.dto.response;

import java.io.Serializable;

import au.com.suncorp.insurance.myservice.model.Hello;
import au.com.suncorp.insurance.gi.api.common.rest.dto.jsonapi.response.ResponseData;
import au.com.suncorp.insurance.gi.api.common.rest.dto.jsonapi.response.ResponseResource;
import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class HelloResponseDTO extends ResponseResource<Hello> implements Serializable {
    private static final String RESOURCE = "hello";

    public HelloResponseDTO(Hello hello) {
        ResponseData<Hello> data = new ResponseData<>(RESOURCE, hello.getCustomerId(), hello);
        setData(data);
    }

    @Override
    public String toString() {
        return super.toStringHelper().toString();
    }
}
