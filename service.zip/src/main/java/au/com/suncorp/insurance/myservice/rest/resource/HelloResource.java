////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2016, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////

package au.com.suncorp.insurance.myservice.rest.resource;

import static au.com.suncorp.insurance.gi.api.common.constant.CommonConstants.ACCEPT_APPLICATION_JSON_API_VALUE;
import static au.com.suncorp.insurance.gi.api.common.constant.CommonConstants.APPLICATION_JSON_API_VALUE;

import javax.validation.Valid;

import au.com.suncorp.insurance.myservice.model.Hello;
import au.com.suncorp.insurance.myservice.provider.DependentService;
import au.com.suncorp.insurance.myservice.rest.dto.request.HelloRequestDTO;
import au.com.suncorp.insurance.myservice.rest.dto.response.HelloResponseDTO;
import au.com.suncorp.insurance.gi.api.common.constant.CommonConstants;
import com.codahale.metrics.annotation.Timed;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(CommonConstants.REST_BASE_URL_PATTERN)
public class HelloResource {
    private final Logger logger = LoggerFactory.getLogger(this.getClass());
    private final DependentService dependentCustomerService;

    @Autowired
    public HelloResource(DependentService dependentCustomerService) {
        this.dependentCustomerService = dependentCustomerService;
    }

    @ApiOperation(value = "Hello", notes = "Display hello greeting", nickname = "hello")
    @ApiImplicitParam(value = "JSON API format", name = "Accept", allowableValues = APPLICATION_JSON_API_VALUE, paramType = "header", dataType = "String", required = true)
    @RequestMapping(value = "/hello", method = RequestMethod.GET, headers = ACCEPT_APPLICATION_JSON_API_VALUE, produces = APPLICATION_JSON_API_VALUE)
    @Timed(absolute = true, name = "timer.rest.hello")
    public ResponseEntity<HelloResponseDTO> hello(@Valid @ModelAttribute HelloRequestDTO helloRequestDTO) {
        logger.info("Request: " + helloRequestDTO);

        Hello hello = dependentCustomerService.hello(helloRequestDTO.getName(), helloRequestDTO.getTitle());
        HelloResponseDTO helloResponseDTO = new HelloResponseDTO(hello);

        ResponseEntity<HelloResponseDTO> responseEntity = new ResponseEntity<>(helloResponseDTO, HttpStatus.OK);

        logger.info("Response: " + responseEntity);

        return responseEntity;
    }
}
