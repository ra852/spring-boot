////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2016, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////

package au.com.suncorp.insurance.myservice.stub;

import au.com.suncorp.insurance.gi.api.common.rest.stub.JsonToObjectMapper;
import au.com.suncorp.insurance.gi.api.common.rest.stub.RestOperationsStub;
import au.com.suncorp.insurance.myservice.provider.domain.CustomerResponseVO;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

public class DependentServiceRestOperationsStub extends RestOperationsStub {
    private JsonToObjectMapper<CustomerResponseVO> mapper = new JsonToObjectMapper<>(CustomerResponseVO.class);

    @SuppressWarnings("unchecked")
    @Override
    public <T> ResponseEntity<T> exchange(String url, HttpMethod method, HttpEntity<?> requestEntity,
                                          Class<T> responseType, Object... uriVariables) {
        try {
            CustomerResponseVO response = mapper.mapFromFile("/stubs/dependent-service-response.json");
            return (ResponseEntity<T>) new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

}
