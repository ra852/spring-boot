////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2017, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package au.com.suncorp.insurance.myservice.apidoc;

import static au.com.suncorp.insurance.gi.api.common.constant.CommonConstants.APPLICATION_JSON_API_VALUE;
import static au.com.suncorp.insurance.gi.api.common.constant.CommonConstants.CLIENT_ID_FIELD_NAME;
import static au.com.suncorp.insurance.gi.api.common.constant.CommonConstants.CLIENT_VERSION_FIELD_NAME;
import static au.com.suncorp.insurance.gi.api.common.constant.CommonConstants.CORRELATION_ID_FIELD_NAME;
import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.restdocs.mockmvc.MockMvcRestDocumentation.document;
import static org.springframework.restdocs.operation.preprocess.Preprocessors.preprocessResponse;
import static org.springframework.restdocs.operation.preprocess.Preprocessors.prettyPrint;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.io.BufferedWriter;
import java.io.File;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;

import au.com.suncorp.insurance.myservice.Application;
import au.com.suncorp.insurance.myservice.constant.Constants;
import org.apache.commons.io.FileUtils;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.restdocs.AutoConfigureRestDocs;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;

@WebAppConfiguration
@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = Application.class)
@AutoConfigureMockMvc
@AutoConfigureRestDocs(outputDir = "build/asciidoc/generated/snippets")
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
@ActiveProfiles({ Constants.SPRING_PROFILE_TEST })
public class SwaggerToMarkupTest {
    private static final String ASCIIDOC_SNIPPETS_PARENT_FOLDER = "build/asciidoc/generated/snippets";
    private static final String SWAGGER_JSON_FILE = "swagger.json";

    private static final String CORRELATION_ID_VALUE = "846578DFJ09383733FDLXW12";
    private static final String CLIENT_ID_VALUE = "consumer";
    private static final String CLIENT_VERSION_VALUE = "1.0.1";

    @Autowired
    private MockMvc mockMvc;

    @Test
    public void createSpringfoxSwaggerJson() throws Exception {
        // given
        String outputDir = System.getProperty("io.springfox.staticdocs.outputDir");

        // when
        MvcResult mvcResult = this.mockMvc.perform(get("/v2/api-docs")
                .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andReturn();

        MockHttpServletResponse response = mvcResult.getResponse();
        String swaggerJson = response.getContentAsString();
        Files.createDirectories(Paths.get(outputDir));
        try (BufferedWriter writer = Files.newBufferedWriter(Paths.get(outputDir, SWAGGER_JSON_FILE), StandardCharsets.UTF_8)) {
            writer.write(swaggerJson);
        }

        // then
        String[] files = new File(outputDir).list();
        assertThat(files).contains(SWAGGER_JSON_FILE);
    }

    @Test
    public void hello() throws Exception {
        // given
        String apiOperationName = "hello";

        MockHttpServletRequestBuilder requestBuilder = get("/api/hello?name=James")
                .accept(APPLICATION_JSON_API_VALUE)
                .header(CORRELATION_ID_FIELD_NAME, CORRELATION_ID_VALUE)
                .header(CLIENT_ID_FIELD_NAME, CLIENT_ID_VALUE)
                .header(CLIENT_VERSION_FIELD_NAME, CLIENT_VERSION_VALUE);

        // when
        ResultActions actions = mockMvc.perform(requestBuilder);
        actions.andDo(document(apiOperationName, preprocessResponse(prettyPrint())));

        // then
        actions.andExpect(status().isOk());

        String[] files = new File(ASCIIDOC_SNIPPETS_PARENT_FOLDER + "/" + apiOperationName).list();
        assertThat(files).contains("curl-request.adoc", "http-request.adoc", "http-response.adoc");

        String httpResponseDocContent = getHttpResponseDocContent(apiOperationName);
        assertThat(httpResponseDocContent).contains("\"type\" : \"hello\"");
        assertThat(httpResponseDocContent).contains("\"id\"");
        assertThat(httpResponseDocContent).contains("\"customerId\" : \"1000\"");
        assertThat(httpResponseDocContent).contains("\"customerName\" : \"James\"");
        assertThat(httpResponseDocContent).contains("\"message\" : \"Hi James, Hello There Too!\"");
    }

    @Test
    public void helloByNameAndTitle() throws Exception {
        // given
        String apiOperationName = "helloByNameAndTitle";

        MockHttpServletRequestBuilder requestBuilder = get("/api/hello?name=James&title=Mr")
                .accept(APPLICATION_JSON_API_VALUE)
                .header(CORRELATION_ID_FIELD_NAME, CORRELATION_ID_VALUE)
                .header(CLIENT_ID_FIELD_NAME, CLIENT_ID_VALUE)
                .header(CLIENT_VERSION_FIELD_NAME, CLIENT_VERSION_VALUE);

        // when
        ResultActions actions = mockMvc.perform(requestBuilder);
        actions.andDo(document(apiOperationName, preprocessResponse(prettyPrint())));

        // then
        actions.andExpect(status().isOk());

        String[] files = new File(ASCIIDOC_SNIPPETS_PARENT_FOLDER + "/" + apiOperationName).list();
        assertThat(files).contains("curl-request.adoc", "http-request.adoc", "http-response.adoc");

        String httpResponseDocContent = getHttpResponseDocContent(apiOperationName);
        assertThat(httpResponseDocContent).contains("\"type\" : \"hello\"");
        assertThat(httpResponseDocContent).contains("\"id\"");
        assertThat(httpResponseDocContent).contains("\"customerId\" : \"1000\"");
        assertThat(httpResponseDocContent).contains("\"customerName\" : \"James\"");
        assertThat(httpResponseDocContent).contains("\"message\" : \"Hi Mr James, Hello There Too!\"");
    }

    private String getHttpResponseDocContent(String apiOperationName) throws Exception {
        return FileUtils.readFileToString(new File(ASCIIDOC_SNIPPETS_PARENT_FOLDER + "/" + apiOperationName + "/" + "http-response.adoc"), Charset.defaultCharset());
    }
}
