////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2016, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////

package au.com.suncorp.insurance.myservice.provider;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.not;
import static org.hamcrest.CoreMatchers.nullValue;
import static org.junit.Assert.assertThat;
import static org.mockito.MockitoAnnotations.initMocks;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.method;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.requestTo;
import static org.springframework.test.web.client.response.MockRestResponseCreators.withServerError;
import static org.springframework.test.web.client.response.MockRestResponseCreators.withSuccess;

import java.io.File;
import java.net.URL;
import java.nio.charset.Charset;

import au.com.suncorp.insurance.myservice.config.properties.DependentServiceProperties;
import au.com.suncorp.insurance.myservice.model.Hello;
import au.com.suncorp.insurance.myservice.provider.mapper.HelloMapper;
import au.com.suncorp.insurance.gi.api.common.constant.CommonConstants;
import org.apache.commons.io.FileUtils;
import org.junit.Before;
import org.junit.Test;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.test.web.client.MockRestServiceServer;
import org.springframework.web.client.RestTemplate;

public class DependentServiceTest {
    private static final String REQUEST_URL = "http://example.service.com/api/customer/James";
    private static final String VALID_RESPONSE = "/providers/dependent-service-response-valid.json";

    private DependentService dependentCustomerService;
    private DependentServiceProperties dependantServiceProperties;
    private RestTemplate restTemplate;
    private MockRestServiceServer mockServer;

    @Before
    public void setUp() throws Exception {
        initMocks(this);

        restTemplate = new RestTemplate();
        mockServer = MockRestServiceServer.createServer(restTemplate);

        dependantServiceProperties = new DependentServiceProperties();
        dependantServiceProperties.setAddress(new DependentServiceProperties.Address());
        dependantServiceProperties.getAddress().setBase("http://example.service.com");
        dependantServiceProperties.getAddress().setService("/api/customer/{name}");

        dependentCustomerService = new DependentService(restTemplate, dependantServiceProperties, new HelloMapper());
    }

    @Test
    public void shouldReturnValidResponse() throws Exception {
        // given
        mockServer.expect(requestTo(REQUEST_URL))
                .andExpect(method(HttpMethod.GET))
                .andRespond(withSuccess(jsonResponse(VALID_RESPONSE),
                        MediaType.valueOf(CommonConstants.APPLICATION_JSON_API_VALUE)));

        // when
        Hello hello = dependentCustomerService.hello("James", "Mr");

        // then
        mockServer.verify();
        assertThat(hello.getCustomerId(), is(not(nullValue())));
        assertThat(hello.getCustomerName(), is("James"));
        assertThat(hello.getMessage(), is(not(nullValue())));
    }

    @Test(expected = RuntimeException.class)
    public void shouldThrowExceptionIfServerError() throws Exception {
        // given
        mockServer.expect(requestTo(REQUEST_URL))
                .andExpect(method(HttpMethod.GET))
                .andRespond(withServerError());

        // when
        dependentCustomerService.hello("James", "Mr");

        // then
        // throw Exception
    }

    private String jsonResponse(String filename) throws Exception {
        URL url = this.getClass().getResource(filename);
        File file = new File(url.toURI());
        return FileUtils.readFileToString(file, Charset.defaultCharset());
    }
}