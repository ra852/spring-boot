////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2016, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package au.com.suncorp.insurance.myservice.provider.mapper;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;

import au.com.suncorp.insurance.myservice.model.Hello;
import au.com.suncorp.insurance.myservice.provider.domain.CustomerResponseVO;
import org.junit.Before;
import org.junit.Test;

public class HelloMapperTest {
    private HelloMapper helloMapper;

    @Before
    public void setUp() {
        helloMapper = new HelloMapper();
    }

    @Test
    public void shouldMapCustomerVOToHello() {
        //given
        CustomerResponseVO customerVO = new CustomerResponseVO();
        customerVO.setId("1");
        customerVO.setFirstName("John");
        customerVO.setSurname("Smith");

        //when
        Hello hello = helloMapper.map(customerVO, Hello.class);

        //then
        assertThat(hello.getCustomerId(), is("1"));
        assertThat(hello.getCustomerName(), is("John"));
    }
}