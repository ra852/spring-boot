////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2016, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////

package au.com.suncorp.insurance.myservice.rest.resource;

import static org.hamcrest.CoreMatchers.instanceOf;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.not;
import static org.hamcrest.CoreMatchers.nullValue;
import static org.junit.Assert.assertThat;
import static org.mockito.BDDMockito.given;
import static org.mockito.Matchers.anyString;
import static org.mockito.MockitoAnnotations.initMocks;
import au.com.suncorp.insurance.myservice.model.Hello;
import au.com.suncorp.insurance.myservice.provider.DependentService;
import au.com.suncorp.insurance.myservice.rest.dto.request.HelloRequestDTO;
import au.com.suncorp.insurance.myservice.rest.dto.response.HelloResponseDTO;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

public class HelloResourceTest {
    private static final String NAME = "James";

    private HelloResource helloResource;

    @Mock
    private DependentService mockDependentCustomerService;

    @Before
    public void setUp() throws Exception {
        initMocks(this);

        helloResource = new HelloResource(mockDependentCustomerService);
    }

    @Test
    public void shouldReturn200AsSuccessIndicator() throws Exception {
        //given
        given(mockDependentCustomerService.hello(anyString(), anyString())).willReturn(buildValidResponse());

        HelloRequestDTO helloRequestDTO = new HelloRequestDTO();
        helloRequestDTO.setName(NAME);

        //when
        ResponseEntity<HelloResponseDTO> result = helloResource.hello(helloRequestDTO);

        //then
        assertThat(result.getStatusCode(), is(HttpStatus.OK));
        assertThat(result.getBody(), is(instanceOf(HelloResponseDTO.class)));
        assertThat(result.getBody().getData().getType(), is("hello"));
        assertThat(result.getBody().getData().getId(), is(not(nullValue())));
        assertThat(result.getBody().getData().getAttributes(), instanceOf(Hello.class));
        assertThat(result.getBody().getErrors(), is(nullValue()));
    }

    private Hello buildValidResponse() {
        Hello hello = new Hello();
        hello.setCustomerId("1000");
        hello.setCustomerName(NAME);
        hello.setMessage("Hi " + NAME + ", Hello There Too!");
        return hello;
    }
}