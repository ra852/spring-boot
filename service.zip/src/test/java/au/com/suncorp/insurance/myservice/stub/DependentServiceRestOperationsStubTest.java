////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2017, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package au.com.suncorp.insurance.myservice.stub;

import static org.assertj.core.api.Java6Assertions.assertThat;
import static org.junit.Assert.assertNotNull;
import au.com.suncorp.insurance.myservice.provider.domain.CustomerResponseVO;
import org.junit.Test;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

public class DependentServiceRestOperationsStubTest {

    @Test
    public void shouldReturnHelloResponseFromStub() throws Exception {
        // given
        DependentServiceRestOperationsStub stub = new DependentServiceRestOperationsStub();

        // when
        ResponseEntity<CustomerResponseVO> response = stub.exchange("", HttpMethod.GET, HttpEntity.EMPTY,
                CustomerResponseVO.class, new Object[]{});

        // then
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
        CustomerResponseVO data = response.getBody();
        assertNotNull(data);
        assertThat(data.getFirstName()).isEqualToIgnoringCase("james");
        assertThat(data.getSurname()).isEqualToIgnoringCase("smith");
    }

}