### initialize terraform
```
terraform init
```

### import existing infrastructure
```
terraform import aws_elb.dev springboot-service-stencil-dev
```

### see the plan without action
```
terraform plan
```

### apply infrastructure change
```
terraform apply
```

### import existing infrastructure
```
terraform refresh
```
